# ATC RP

ATC RP is a React Native mobile launcher foundation for Android/iOS focused on SA-MP-style roleplay. The launcher itself is functional: it renders the gaming UI, loads servers/news/mods from the backend, authenticates users, securely stores sessions, downloads/verifies remote assets, and installs assets only into an ATC RP-owned runtime directory. The actual GTA/SA-MP game runtime is **not bundled** and the Play/Connect path refuses to claim success until a licensed native adapter reports itself linked.

## What is implemented

- Home, server browser/search/select/connect flow, dedicated ATC RP server view, Mods, Profile, Settings, dark red/black launcher UI.
- Backend routes: `GET /servers`, `/servers/:id`, `/news`, `/mods`, `/mods/:id`, `/modpacks`, `/versions`, `/download/:file`; `POST /auth/login`, `/auth/register`.
- Admin API + minimal admin HTML for servers, news, mods, modpacks, file upload and download statistics.
- Android native async downloader using OkHttp/coroutines with range resume, 3 retries, SHA-256 verification, corrupted-file deletion, progress events and free-space reporting.
- Android mod installation into `files/game`, SHA-256 recheck, canonical-path protection and pre-overwrite backup.
- Android secure session storage using AndroidX Security encrypted preferences.
- iOS background `URLSession` download bridge skeleton and Keychain secure storage.
- Modular `ATC RP ULTRA REALISTIC` manifest layout. No copyrighted asset is included.
- C++ Android runtime adapter boundary and Objective-C++ iOS runtime boundary that explicitly report "not linked" until you provide licensed components.

## Important unfinished area

The native multiplayer/game engine itself is intentionally **not** faked and is not included. You must supply a properly licensed GTA San Andreas mobile runtime and a compatible, legally distributable SA-MP client integration. See `docs/NATIVE_RUNTIME_INTEGRATION.md`. In-game joystick/camera/action controls and RP overlays should be implemented in the licensed runtime/UI layer once its render surface, event model and TextDraw/dialog APIs are known; inventing those bindings here would create fake multiplayer functionality.

The iOS downloader file contains the real background `URLSession` plumbing but its final SHA-256/move callback is marked for hardening before production. Android contains the full verification/install path today.

## Requirements

- Node.js 22.11+
- Android Studio with Android SDK 36, NDK 27.1.12297006 and CMake 3.22+
- macOS + Xcode for iOS
- CocoaPods

## Install

```bash
npm install
cd backend && npm install && cp .env.example .env && npm run db:init && cd ..
```

Set the launcher API URL in `src/config.ts`. On an Android emulator, `10.0.2.2:8787` reaches the host machine.

### Android

The source tree matches React Native 0.86.3 / New Architecture. Generate a standard debug keystore if `android/app/debug.keystore` is absent, then:

```bash
npm run backend
npm run android
```

#### Build an installable ARM64 APK

A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. Push the repository to GitHub, open **Actions → Build Android APK → Run workflow**, then download the `ATC-RP-Android-APK` artifact. It builds `ATC-RP-android-arm64.apk`.

For a local Android Studio/SDK installation you can also run:

```bash
./scripts/build-android-apk.sh
```

The current `release` build is signed with the included **debug keystore** so the resulting APK is installable for testing, but it is **not a production Play Store signing setup**. Before distribution, create a private release keystore, move secrets out of Gradle source, require HTTPS (`android:usesCleartextTraffic=false`), enable R8/proguard as appropriate, and protect the signing key.


### APK note

This chat build environment does not include the Android SDK/NDK and cannot download build dependencies, so an `.apk` binary is not generated here. The included GitHub Actions workflow runs on a full Android build runner and uploads the finished APK as an artifact.

### iOS

The repository includes `ios/ATCRP.xcodeproj`, the Swift AppDelegate, Podfile, launch storyboard and Objective-C/Objective-C++ native modules. On macOS run:

```bash
npm install
./scripts/bootstrap-ios.sh
```

Then open `ios/ATCRP.xcworkspace` in Xcode, select your signing team, and build. The game runtime bridge remains intentionally unlinked until you add a licensed adapter.

## Backend

```bash
cd backend
cp .env.example .env
npm run db:init
npm run dev
```

Use long random values for `JWT_SECRET` and `ADMIN_API_KEY`. Terminate TLS at a reverse proxy or load balancer. Passwords are hashed with Argon2 and only signed access tokens are stored on-device.

## CDN/object storage layout

```
/atc-rp/
  /versions/
  /modpacks/ultra-realistic/manifest.json
    /cars/
    /bikes/
    /skins/
    /textures/
    /sounds/
  /updates/
  /news/
```

In development, `POST /admin/upload` stores files in `backend/storage` and returns a SHA-256 plus download URL. Production should swap the storage implementation for S3/R2/Backblaze/MinIO and return CDN URLs; manifests remain the same.

## Security/integrity rules

1. Never accept absolute or `..` install paths.
2. Verify game/runtime version before installation.
3. Check free space with safety margin.
4. Download to staging/`.part`, resume when possible, retry transient failures.
5. Verify SHA-256 before install and again at the native install boundary.
6. Back up overwritten files before modification.
7. Use immutable CDN objects/versioned URLs.
8. Keep authentication tokens in Keychain/Keystore-backed storage; never store plaintext passwords.
9. Only distribute GTA/mod/client files when you have authorization.

## Next production milestones

- Complete iOS downloader checksum/atomic staging path and background-completion handler.
- Expand the existing SQLite mod metadata/cache with migrations, reconciliation and orphan-file cleanup.
- Add WorkManager on Android if downloads must survive process death rather than only network interruption/app lifecycle.
- Link licensed runtime adapters and then implement actual in-game control/RP UI bindings against that runtime.
- Add crash reporting, telemetry consent, CDN signed URLs, server query worker, rate limits, refresh tokens, email/account recovery and admin SSO.
