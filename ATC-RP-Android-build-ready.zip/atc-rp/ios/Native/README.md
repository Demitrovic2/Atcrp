# iOS native integration
Add the files in this directory to the `ATCRP` Xcode target after generating/opening the Xcode project. The null game-runtime bridge deliberately reports `runtimeLinked=false`. Replace it only with a licensed runtime adapter that runs inside ATC RP's own sandbox/container. Do not attempt to patch another installed application's private container.
