#import <React/RCTBridgeModule.h>
#import <Foundation/Foundation.h>
@interface ATCGameRuntime : NSObject<RCTBridgeModule>@end
@implementation ATCGameRuntime
RCT_EXPORT_MODULE();
RCT_REMAP_METHOD(getCapabilities,getCapabilitiesWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){resolve(@{@"runtimeLinked":@NO,@"platform":@"ios",@"arm64":@YES});}
RCT_REMAP_METHOD(prepareRuntime,prepareWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){NSArray *u=NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory,NSUserDomainMask,YES);NSString *base=[[u firstObject] stringByAppendingPathComponent:@"ATCRP"];[[NSFileManager defaultManager] createDirectoryAtPath:[base stringByAppendingPathComponent:@"game"] withIntermediateDirectories:YES attributes:nil error:nil];resolve(@YES);}
RCT_REMAP_METHOD(validateRuntime,validateWithResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){resolve(@{@"ok":@NO,@"message":@"Licensed iOS GTA/SA-MP runtime adapter is not linked."});}
RCT_REMAP_METHOD(installAsset,install:(NSString*)staged target:(NSString*)target sha:(NSString*)sha backup:(BOOL)backup resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){reject(@"RUNTIME_NOT_LINKED",@"Install requires the licensed app-owned runtime container adapter.",nil);}
RCT_REMAP_METHOD(removeAsset,removeAsset:(NSString*)target resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){reject(@"RUNTIME_NOT_LINKED",@"Remove requires the licensed app-owned runtime container adapter.",nil);}
RCT_REMAP_METHOD(launch,launch:(NSString*)host port:(nonnull NSNumber*)port nickname:(NSString*)nick token:(NSString*)token resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){reject(@"RUNTIME_NOT_LINKED",@"Licensed SA-MP/GTA runtime adapter is not linked in this build.",nil);}
@end
