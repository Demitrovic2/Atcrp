#import <React/RCTBridgeModule.h>
#import <Security/Security.h>
@interface ATCSecureStore:NSObject<RCTBridgeModule>@end
@implementation ATCSecureStore
RCT_EXPORT_MODULE();
-(NSMutableDictionary*)q:(NSString*)k{return [@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,(__bridge id)kSecAttrService:@"com.atcrp.secure",(__bridge id)kSecAttrAccount:k} mutableCopy];}
RCT_REMAP_METHOD(set,set:(NSString*)k value:(NSString*)v resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){NSMutableDictionary*q=[self q:k];SecItemDelete((__bridge CFDictionaryRef)q);q[(__bridge id)kSecValueData]=[v dataUsingEncoding:NSUTF8StringEncoding];OSStatus s=SecItemAdd((__bridge CFDictionaryRef)q,NULL);s==errSecSuccess?resolve(@YES):reject(@"KEYCHAIN",@"Unable to store secure value",nil);}
RCT_REMAP_METHOD(get,get:(NSString*)k resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){NSMutableDictionary*q=[self q:k];q[(__bridge id)kSecReturnData]=@YES;q[(__bridge id)kSecMatchLimit]=(__bridge id)kSecMatchLimitOne;CFTypeRef result=NULL;OSStatus s=SecItemCopyMatching((__bridge CFDictionaryRef)q,&result);if(s==errSecItemNotFound){resolve([NSNull null]);return;}if(s!=errSecSuccess){reject(@"KEYCHAIN",@"Unable to read secure value",nil);return;}NSData*d=(__bridge_transfer NSData*)result;resolve([[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding]);}
RCT_REMAP_METHOD(remove,remove:(NSString*)k resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){SecItemDelete((__bridge CFDictionaryRef)[self q:k]);resolve(@YES);}
@end
