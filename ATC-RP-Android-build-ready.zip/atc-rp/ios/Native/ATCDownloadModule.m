#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <CommonCrypto/CommonDigest.h>

@interface ATCDownload : RCTEventEmitter<RCTBridgeModule, NSURLSessionDownloadDelegate>
@property(nonatomic,strong) NSURLSession *session;
@property(nonatomic,strong) NSMutableDictionary<NSString*, NSURLSessionDownloadTask*> *tasks;
@property(nonatomic,strong) NSMutableDictionary<NSNumber*, RCTPromiseResolveBlock> *resolvers;
@property(nonatomic,strong) NSMutableDictionary<NSNumber*, RCTPromiseRejectBlock> *rejecters;
@end

@implementation ATCDownload
RCT_EXPORT_MODULE();
+ (BOOL)requiresMainQueueSetup { return NO; }
- (NSArray<NSString*>*)supportedEvents { return @[@"ATCDownloadProgress"]; }
- (instancetype)init {
  if ((self=[super init])) {
    _tasks=[NSMutableDictionary dictionary]; _resolvers=[NSMutableDictionary dictionary]; _rejecters=[NSMutableDictionary dictionary];
    NSURLSessionConfiguration *c=[NSURLSessionConfiguration backgroundSessionConfigurationWithIdentifier:@"com.atcrp.downloads"];
    c.sessionSendsLaunchEvents=YES; c.discretionary=NO;
    _session=[NSURLSession sessionWithConfiguration:c delegate:self delegateQueue:nil];
  }
  return self;
}
RCT_REMAP_METHOD(getFreeSpace,freeResolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject) {
  NSDictionary *a=[[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectory() error:nil]; resolve(a[NSFileSystemFreeSize]);
}
RCT_REMAP_METHOD(cancel,cancel:(NSString*)ident resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject) {
  NSURLSessionTask *t=_tasks[ident]; [t cancel]; [_tasks removeObjectForKey:ident]; resolve(@YES);
}
RCT_REMAP_METHOD(start,start:(NSString*)ident url:(NSString*)url destination:(NSString*)destination sha:(NSString*)sha size:(nonnull NSNumber*)size resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject) {
  if (_tasks[ident]) { reject(@"BUSY",@"Download already active",nil); return; }
  NSURLSessionDownloadTask *t=[_session downloadTaskWithURL:[NSURL URLWithString:url]];
  t.taskDescription=[@[ident,destination,sha] componentsJoinedByString:@"|"];
  _tasks[ident]=t; _resolvers[@(t.taskIdentifier)]=[resolve copy]; _rejecters[@(t.taskIdentifier)]=[reject copy]; [t resume];
}
- (void)URLSession:(NSURLSession*)session downloadTask:(NSURLSessionDownloadTask*)task didWriteData:(int64_t)bytes totalBytesWritten:(int64_t)written totalBytesExpectedToWrite:(int64_t)total {
  NSString *ident=[[task.taskDescription componentsSeparatedByString:@"|"] firstObject];
  [self sendEventWithName:@"ATCDownloadProgress" body:@{@"id":ident?:@"",@"received":@(written),@"total":@(total),@"percent":@(total>0?written*100.0/total:0),@"state":@"downloading"}];
}
- (NSString*)sha256:(NSURL*)url {
  NSInputStream *s=[NSInputStream inputStreamWithURL:url]; [s open]; CC_SHA256_CTX ctx; CC_SHA256_Init(&ctx); uint8_t buf[1024*256];
  while ([s hasBytesAvailable]) { NSInteger n=[s read:buf maxLength:sizeof(buf)]; if(n>0) CC_SHA256_Update(&ctx,buf,(CC_LONG)n); else if(n<0) break; }
  [s close]; unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CC_SHA256_Final(digest,&ctx); NSMutableString *out=[NSMutableString stringWithCapacity:64];
  for(int i=0;i<CC_SHA256_DIGEST_LENGTH;i++) [out appendFormat:@"%02x",digest[i]]; return out;
}
- (void)URLSession:(NSURLSession*)session downloadTask:(NSURLSessionDownloadTask*)task didFinishDownloadingToURL:(NSURL*)location {
  NSArray *parts=[task.taskDescription componentsSeparatedByString:@"|"]; if(parts.count<3) return; NSString *ident=parts[0], *destination=parts[1], *expected=parts[2];
  [self sendEventWithName:@"ATCDownloadProgress" body:@{@"id":ident,@"received":@(task.countOfBytesReceived),@"total":@(task.countOfBytesExpectedToReceive),@"percent":@100,@"state":@"verifying"}];
  NSString *actual=[self sha256:location]; RCTPromiseRejectBlock reject=_rejecters[@(task.taskIdentifier)]; RCTPromiseResolveBlock resolve=_resolvers[@(task.taskIdentifier)];
  if([actual caseInsensitiveCompare:expected] != NSOrderedSame) { if(reject) reject(@"CHECKSUM",@"SHA-256 mismatch; corrupted download rejected",nil); return; }
  NSURL *base=[[[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask] firstObject]; base=[base URLByAppendingPathComponent:@"ATCRP" isDirectory:YES]; NSURL *out=[base URLByAppendingPathComponent:destination];
  [[NSFileManager defaultManager] createDirectoryAtURL:[out URLByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil]; [[NSFileManager defaultManager] removeItemAtURL:out error:nil];
  NSError *err=nil; [[NSFileManager defaultManager] moveItemAtURL:location toURL:out error:&err]; if(err){ if(reject) reject(@"MOVE_FAILED",err.localizedDescription,err); return; }
  [self sendEventWithName:@"ATCDownloadProgress" body:@{@"id":ident,@"received":@(task.countOfBytesReceived),@"total":@(task.countOfBytesReceived),@"percent":@100,@"state":@"complete"}]; if(resolve) resolve(@YES);
  [_tasks removeObjectForKey:ident]; [_resolvers removeObjectForKey:@(task.taskIdentifier)]; [_rejecters removeObjectForKey:@(task.taskIdentifier)];
}
- (void)URLSession:(NSURLSession*)session task:(NSURLSessionTask*)task didCompleteWithError:(NSError*)error {
  if(!error) return; NSArray *parts=[task.taskDescription componentsSeparatedByString:@"|"]; NSString *ident=parts.count?parts[0]:@""; RCTPromiseRejectBlock reject=_rejecters[@(task.taskIdentifier)]; if(reject) reject(@"DOWNLOAD_FAILED",error.localizedDescription,error); [_tasks removeObjectForKey:ident]; [_resolvers removeObjectForKey:@(task.taskIdentifier)]; [_rejecters removeObjectForKey:@(task.taskIdentifier)];
}
@end
