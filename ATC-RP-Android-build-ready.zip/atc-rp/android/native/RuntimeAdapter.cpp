#include <jni.h>
#include <string>
// Replace this null adapter with an authorized SA-MP/GTA mobile runtime integration.
extern "C" JNIEXPORT jboolean JNICALL Java_com_atcrp_ATCGameRuntimeModule_nativeRuntimeLinked(JNIEnv*, jobject){return JNI_FALSE;}
extern "C" JNIEXPORT jstring JNICALL Java_com_atcrp_ATCGameRuntimeModule_nativeLaunch(JNIEnv* env,jobject,jstring,jint,jstring,jstring){return env->NewStringUTF("Licensed SA-MP/GTA runtime adapter is not linked in this build.");}
