package com.atcrp
import com.facebook.react.bridge.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
class ATCSecureStoreModule(private val ctx:ReactApplicationContext):ReactContextBaseJavaModule(ctx){
 override fun getName()="ATCSecureStore"
 private val prefs by lazy{val key=MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();EncryptedSharedPreferences.create(ctx,"atc_secure",key,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)}
 @ReactMethod fun set(k:String,v:String,p:Promise){prefs.edit().putString(k,v).apply();p.resolve(true)}
 @ReactMethod fun get(k:String,p:Promise)=p.resolve(prefs.getString(k,null))
 @ReactMethod fun remove(k:String,p:Promise){prefs.edit().remove(k).apply();p.resolve(true)}
}
