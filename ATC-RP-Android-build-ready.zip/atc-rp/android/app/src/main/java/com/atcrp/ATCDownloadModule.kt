package com.atcrp
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import kotlinx.coroutines.*
import okhttp3.*
import java.io.*
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
class ATCDownloadModule(private val ctx:ReactApplicationContext):ReactContextBaseJavaModule(ctx){
 private val client=OkHttpClient.Builder().retryOnConnectionFailure(true).build(); private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO); private val jobs=ConcurrentHashMap<String,Job>()
 override fun getName()="ATCDownload"
 @ReactMethod fun addListener(name:String){} @ReactMethod fun removeListeners(count:Int){}
 @ReactMethod fun getFreeSpace(p:Promise)=p.resolve(ctx.filesDir.usableSpace.toDouble())
 @ReactMethod fun cancel(id:String,p:Promise){jobs.remove(id)?.cancel();p.resolve(true)}
 @ReactMethod fun start(id:String,url:String,dest:String,sha:String,expectedSize:Double,p:Promise){if(jobs.containsKey(id)){p.reject("BUSY","Download already active");return}; val job=scope.launch{try{download(id,url,dest,sha,expectedSize.toLong());withContext(Dispatchers.Main){p.resolve(true)}}catch(e:CancellationException){withContext(Dispatchers.Main){p.reject("CANCELLED","Download cancelled")}}catch(e:Throwable){emit(id,0,expectedSize.toLong(),"failed");withContext(Dispatchers.Main){p.reject("DOWNLOAD_FAILED",e)}}finally{jobs.remove(id)}};jobs[id]=job}
 private suspend fun download(id:String,url:String,dest:String,sha:String,expected:Long){val out=File(ctx.filesDir,dest);out.parentFile?.mkdirs();val part=File(out.path+".part");var offset=if(part.exists())part.length() else 0L;var attempts=0;while(true){try{val rb=Request.Builder().url(url);if(offset>0)rb.header("Range","bytes=$offset-");client.newCall(rb.build()).execute().use{r->if(!r.isSuccessful)error("HTTP ${r.code}");val body=r.body?:error("Empty body");if(offset>0 && r.code!=206){offset=0;part.delete()};val total=when{r.code==206->offset+body.contentLength();body.contentLength()>0->body.contentLength();else->expected};RandomAccessFile(part,"rw").use{raf->if(offset==0L)raf.setLength(0);raf.seek(offset);val input=body.byteStream();val buf=ByteArray(256*1024);var last=0L;while(true){currentCoroutineContext().ensureActive();val n=input.read(buf);if(n<0)break;raf.write(buf,0,n);offset+=n;if(offset-last>256*1024){emit(id,offset,total,"downloading");last=offset}}};emit(id,offset,total,"verifying")};break}catch(e:Throwable){attempts++;if(attempts>=3)throw e;delay(800L*attempts)}};val actual=sha256(part);if(!actual.equals(sha,true)){part.delete();error("SHA-256 mismatch; corrupted file deleted")};if(out.exists())out.delete();if(!part.renameTo(out)){part.copyTo(out,true);part.delete()};emit(id,out.length(),out.length(),"complete")}
 private fun emit(id:String,received:Long,total:Long,state:String){val m=Arguments.createMap();m.putString("id",id);m.putDouble("received",received.toDouble());m.putDouble("total",total.toDouble());m.putDouble("percent",if(total>0)received*100.0/total else 0.0);m.putString("state",state);ctx.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit("ATCDownloadProgress",m)}
 private fun sha256(f:File):String{val md=MessageDigest.getInstance("SHA-256");f.inputStream().use{i->val b=ByteArray(1024*1024);while(true){val n=i.read(b);if(n<=0)break;md.update(b,0,n)}};return md.digest().joinToString(""){"%02x".format(it)}}
}
