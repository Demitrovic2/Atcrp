package com.atcrp
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager
class ATCNativePackage:ReactPackage{
 override fun createNativeModules(c:ReactApplicationContext):List<NativeModule> = listOf(ATCGameRuntimeModule(c),ATCDownloadModule(c),ATCSecureStoreModule(c),ATCLocalDbModule(c))
 override fun createViewManagers(c:ReactApplicationContext):List<ViewManager<*,*>> = emptyList()
}
