package com.atcrp
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Context
import com.facebook.react.bridge.*
class ATCLocalDbModule(private val ctx:ReactApplicationContext):ReactContextBaseJavaModule(ctx){
 override fun getName()="ATCLocalDb"
 private val helper=object:SQLiteOpenHelper(ctx,"launcher.db",null,1){override fun onCreate(db:SQLiteDatabase){db.execSQL("CREATE TABLE installed_mods(id TEXT PRIMARY KEY,version TEXT NOT NULL,enabled INTEGER NOT NULL,installed_at TEXT NOT NULL,files_json TEXT NOT NULL)")};override fun onUpgrade(db:SQLiteDatabase,old:Int,new:Int){}}
 @ReactMethod fun list(p:Promise){try{val arr=Arguments.createArray();helper.readableDatabase.rawQuery("SELECT id,version,enabled,installed_at,files_json FROM installed_mods ORDER BY installed_at DESC",null).use{c->while(c.moveToNext()){val m=Arguments.createMap();m.putString("id",c.getString(0));m.putString("version",c.getString(1));m.putBoolean("enabled",c.getInt(2)==1);m.putString("installedAt",c.getString(3));m.putString("filesJson",c.getString(4));arr.pushMap(m)}};p.resolve(arr)}catch(e:Throwable){p.reject("DB",e)}}
 @ReactMethod fun get(id:String,p:Promise){try{helper.readableDatabase.rawQuery("SELECT id,version,enabled,installed_at,files_json FROM installed_mods WHERE id=?",arrayOf(id)).use{c->if(!c.moveToFirst()){p.resolve(null);return};val m=Arguments.createMap();m.putString("id",c.getString(0));m.putString("version",c.getString(1));m.putBoolean("enabled",c.getInt(2)==1);m.putString("installedAt",c.getString(3));m.putString("filesJson",c.getString(4));p.resolve(m)}}catch(e:Throwable){p.reject("DB",e)}}
 @ReactMethod fun put(id:String,version:String,enabled:Boolean,installedAt:String,filesJson:String,p:Promise){try{helper.writableDatabase.execSQL("INSERT OR REPLACE INTO installed_mods(id,version,enabled,installed_at,files_json) VALUES(?,?,?,?,?)",arrayOf(id,version,if(enabled)1 else 0,installedAt,filesJson));p.resolve(true)}catch(e:Throwable){p.reject("DB",e)}}
 @ReactMethod fun remove(id:String,p:Promise){helper.writableDatabase.delete("installed_mods","id=?",arrayOf(id));p.resolve(true)}
 @ReactMethod fun setEnabled(id:String,enabled:Boolean,p:Promise){val v=android.content.ContentValues();v.put("enabled",if(enabled)1 else 0);helper.writableDatabase.update("installed_mods",v,"id=?",arrayOf(id));p.resolve(true)}
}
