package com.atcrp
import com.facebook.react.bridge.*
import java.io.File
import java.security.MessageDigest
class ATCGameRuntimeModule(private val ctx:ReactApplicationContext):ReactContextBaseJavaModule(ctx){
 companion object{init{System.loadLibrary("atcrp_native")}}
 override fun getName()="ATCGameRuntime"
 external fun nativeRuntimeLinked():Boolean
 external fun nativeLaunch(host:String,port:Int,nickname:String,token:String):String
 @ReactMethod fun getCapabilities(p:Promise){val m=Arguments.createMap();m.putBoolean("runtimeLinked",nativeRuntimeLinked());m.putString("platform","android");m.putBoolean("arm64",android.os.Build.SUPPORTED_ABIS.contains("arm64-v8a"));p.resolve(m)}
 @ReactMethod fun prepareRuntime(p:Promise){File(ctx.filesDir,"game").mkdirs();File(ctx.filesDir,"staging").mkdirs();p.resolve(true)}
 @ReactMethod fun validateRuntime(p:Promise){val m=Arguments.createMap();val ok=nativeRuntimeLinked()&&File(ctx.filesDir,"game").exists();m.putBoolean("ok",ok);m.putString("message",if(ok)"Runtime ready" else "Licensed game runtime adapter is not linked or prepared");p.resolve(m)}
 @ReactMethod fun installAsset(staged:String,target:String,sha:String,backup:Boolean,p:Promise){try{val src=File(ctx.filesDir,staged);require(src.exists()){ "Staged file missing" };val actual=sha256(src);require(actual.equals(sha,true)){"SHA-256 mismatch"};val dst=File(ctx.filesDir,"game/$target").canonicalFile;val base=File(ctx.filesDir,"game").canonicalFile;require(dst==base || dst.path.startsWith(base.path+File.separator)){"Unsafe install path"};dst.parentFile?.mkdirs();if(backup&&dst.exists()){val b=File(ctx.filesDir,"backup/$target.${System.currentTimeMillis()}");b.parentFile?.mkdirs();dst.copyTo(b,true)};src.copyTo(dst,true);p.resolve(true)}catch(e:Throwable){p.reject("INSTALL_FAILED",e)}}
 @ReactMethod fun removeAsset(target:String,p:Promise){try{val dst=File(ctx.filesDir,"game/$target").canonicalFile;val base=File(ctx.filesDir,"game").canonicalFile;require(dst==base || dst.path.startsWith(base.path+File.separator)){"Unsafe remove path"};if(dst.exists()&&!dst.delete())error("Unable to remove asset");p.resolve(true)}catch(e:Throwable){p.reject("REMOVE_FAILED",e)}}
 @ReactMethod fun launch(host:String,port:Int,nickname:String,token:String,p:Promise){val result=nativeLaunch(host,port,nickname,token);if(result=="OK")p.resolve(true)else p.reject("RUNTIME_NOT_LINKED",result)}
 private fun sha256(f:File):String{val md=MessageDigest.getInstance("SHA-256");f.inputStream().use{i->val b=ByteArray(1024*1024);while(true){val n=i.read(b);if(n<=0)break;md.update(b,0,n)}};return md.digest().joinToString(""){"%02x".format(it)}}
}
