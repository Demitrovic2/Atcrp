# ATC RP project-specific ProGuard rules.
