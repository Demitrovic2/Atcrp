@echo off
set DIR=%~dp0
if exist "%DIR%gradle\wrapper\gradle-wrapper.jar" goto wrapper
powershell -NoProfile -ExecutionPolicy Bypass -Command "$v='9.3.1'; $base=Join-Path $env:USERPROFILE '.gradle\atcrp-bootstrap'; $g=Join-Path $base ('gradle-'+$v); if(!(Test-Path (Join-Path $g 'bin\gradle.bat'))){$z=Join-Path $env:TEMP ('gradle-'+$v+'-bin.zip'); Invoke-WebRequest ('https://services.gradle.org/distributions/gradle-'+$v+'-bin.zip') -OutFile $z; New-Item -ItemType Directory -Force -Path $base|Out-Null; Expand-Archive -Force $z $base}; & (Join-Path $g 'bin\gradle.bat') -p '%DIR%' %*"
exit /b %ERRORLEVEL%
:wrapper
java -classpath "%DIR%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
