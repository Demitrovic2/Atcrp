# Mod manifest
Each file entry is immutable and content-addressed by SHA-256. `installationPath` is always relative to the ATC RP owned runtime directory; traversal (`..`) and absolute paths must be rejected by native installers. The CDN URL must serve only assets you are licensed to distribute.

Example fields: `version`, `requiredGameVersion`, `files[].path`, `files[].sha256`, `files[].size`, `files[].downloadUrl`, `files[].installationPath`.
