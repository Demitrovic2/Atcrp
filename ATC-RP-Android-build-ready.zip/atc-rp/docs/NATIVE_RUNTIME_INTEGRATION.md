# Native runtime integration contract

The launcher does **not** ship GTA San Andreas, Rockstar assets, SA-MP binaries, reverse-engineered proprietary code, or third-party mods without distribution permission.

`ATCGameRuntime` is the only boundary the TypeScript launcher uses. A licensed adapter must implement:

- capability reporting (`runtimeLinked`)
- runtime preparation in an app-owned directory
- game/version verification
- atomic asset installation with backup
- launch/connect(host, port, nickname, token)
- lifecycle/crash reporting
- input/controller forwarding if the runtime does not own its own window

Android C++ entry points currently return `runtimeLinked=false`. Replace `android/native/RuntimeAdapter.cpp` with your authorized SDK/client adapter and preserve the same JNI contract. iOS uses an Objective-C++/React Native module and must keep runtime/game data in ATC RP's own container unless your licensed distribution model provides another Apple-approved mechanism.
