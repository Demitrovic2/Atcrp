#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../ios"
if ! command -v pod >/dev/null 2>&1; then echo "CocoaPods is required (brew install cocoapods)." >&2; exit 1; fi
pod install
echo "Open ios/ATCRP.xcworkspace in Xcode."
