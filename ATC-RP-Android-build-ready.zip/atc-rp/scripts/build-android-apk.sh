#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22+ is required." >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo "ANDROID_HOME or ANDROID_SDK_ROOT must point to Android SDK 36." >&2
  exit 1
fi
if [[ ! -f android/gradle/wrapper/gradle-wrapper.jar ]]; then
  if command -v gradle >/dev/null 2>&1; then
    (cd android && gradle wrapper --gradle-version 9.3.1)
  else
    echo "Gradle wrapper JAR is missing. Install Gradle 9.3.1 once, then run: cd android && gradle wrapper --gradle-version 9.3.1" >&2
    exit 1
  fi
fi

npm install --no-audit --no-fund
(
  cd android
  chmod +x gradlew
  ./gradlew clean app:assembleRelease -PreactNativeArchitectures=arm64-v8a
)

APK="$ROOT/android/app/build/outputs/apk/release/app-release.apk"
if [[ ! -f "$APK" ]]; then
  echo "APK build completed without expected output: $APK" >&2
  exit 1
fi
mkdir -p "$ROOT/dist"
cp "$APK" "$ROOT/dist/ATC-RP-android-arm64.apk"
echo "APK: $ROOT/dist/ATC-RP-android-arm64.apk"
