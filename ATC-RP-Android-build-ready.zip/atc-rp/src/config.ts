export const API_URL = 'http://10.0.2.2:8787';
export const APP_VERSION = '0.1.0';
export const SUPPORTED_GAME_VERSION = 'mobile-runtime-licensed-v1';
