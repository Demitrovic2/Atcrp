export const theme = {
  bg:'#08090b', panel:'#111318', panel2:'#171a20', text:'#f5f7fa', muted:'#8e96a3', red:'#e22d3e', red2:'#ff4655', border:'#272b34', good:'#43d17a', warning:'#f0aa3c'
};
