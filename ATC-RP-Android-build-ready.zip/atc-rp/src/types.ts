export type Server = {
  id: string; name: string; host: string; port: number; online: number; maxPlayers: number;
  ping?: number; status: 'online'|'offline'|'maintenance'; featured?: boolean; version: string;
  description?: string; rules?: string[]; discordUrl?: string;
};
export type NewsItem = {id:string; title:string; body:string; publishedAt:string};
export type ModCategory = 'cars'|'bikes'|'skins'|'weapons'|'textures'|'maps'|'sounds'|'ui'|'effects';
export type ModFile = {path:string; sha256:string; size:number; downloadUrl:string; installPath:string};
export type Mod = {id:string; name:string; version:string; size:number; description:string; category:ModCategory; previewUrl?:string; requiredGameVersion:string; files:ModFile[]};
export type Modpack = {id:string; name:string; version:string; description:string; categories:ModCategory[]; mods:string[]};
export type DownloadProgress = {id:string; received:number; total:number; percent:number; state:'queued'|'downloading'|'verifying'|'complete'|'failed'};
export type GraphicsQuality = 'Low'|'Medium'|'High'|'Ultra';
