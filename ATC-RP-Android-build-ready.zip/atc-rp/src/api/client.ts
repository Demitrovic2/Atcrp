import {API_URL} from '../config';
let token: string | null = null;
export const setApiToken=(value:string|null)=>{token=value};
export async function api<T>(path:string, init:RequestInit={}):Promise<T>{
  const headers:any={Accept:'application/json','Content-Type':'application/json',...(init.headers||{})};
  if(token) headers.Authorization=`Bearer ${token}`;
  const res=await fetch(`${API_URL}${path}`,{...init,headers});
  if(!res.ok){const body=await res.text(); throw new Error(body||`HTTP ${res.status}`)}
  return res.json() as Promise<T>;
}
