/**
 * Local mod metadata contract. The production implementation is expected to use the platform SQLite adapter.
 * Keeping this interface isolated prevents UI code from depending on a specific database library.
 */
export type InstalledMod={id:string;version:string;enabled:boolean;installedAt:string;files:{path:string;sha256:string}[]};
export interface ModMetadataStore{list():Promise<InstalledMod[]>;get(id:string):Promise<InstalledMod|null>;put(mod:InstalledMod):Promise<void>;remove(id:string):Promise<void>;setEnabled(id:string,enabled:boolean):Promise<void>}
