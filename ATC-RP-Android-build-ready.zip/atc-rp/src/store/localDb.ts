import {NativeModules} from 'react-native';
import type {InstalledMod,ModMetadataStore} from './modMetadata';
const db=NativeModules.ATCLocalDb;
const decode=(x:any):InstalledMod=>({id:x.id,version:x.version,enabled:!!x.enabled,installedAt:x.installedAt,files:JSON.parse(x.filesJson||'[]')});
export const localModDb:ModMetadataStore={
 async list(){return (await db.list()).map(decode)},
 async get(id){const x=await db.get(id);return x?decode(x):null},
 async put(m){await db.put(m.id,m.version,m.enabled,m.installedAt,JSON.stringify(m.files))},
 async remove(id){await db.remove(id)},
 async setEnabled(id,enabled){await db.setEnabled(id,enabled)}
};
