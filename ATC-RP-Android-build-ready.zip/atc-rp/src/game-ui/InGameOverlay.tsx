import React from 'react';
import {Pressable,StyleSheet,Text,View} from 'react-native';
import {theme} from '../theme';

export type GameAction='jump'|'enterVehicle'|'exitVehicle'|'fire'|'sprint'|'crouch'|'interact'|'chat'|'inventory'|'map'|'settings';
export type InputSink=(action:GameAction,pressed:boolean)=>void;
const actions:[GameAction,string][]=[['jump','JUMP'],['enterVehicle','ENTER'],['exitVehicle','EXIT'],['fire','FIRE'],['sprint','SPRINT'],['crouch','CROUCH'],['interact','USE'],['chat','CHAT'],['inventory','INV'],['map','MAP'],['settings','⚙']];

/** Runtime-agnostic control surface. Mount over the licensed game's render surface and wire onAction to its input adapter. */
export function InGameOverlay({onAction}:{onAction:InputSink}){
 return <View pointerEvents="box-none" style={StyleSheet.absoluteFill}>
   <View style={s.joystick}><View style={s.knob}/></View>
   <View style={s.actions}>{actions.map(([a,label])=><Pressable key={a} onPressIn={()=>onAction(a,true)} onPressOut={()=>onAction(a,false)} style={s.button}><Text style={s.text}>{label}</Text></Pressable>)}</View>
 </View>
}
const s=StyleSheet.create({joystick:{position:'absolute',left:28,bottom:38,width:128,height:128,borderRadius:64,borderWidth:2,borderColor:'#ffffff55',backgroundColor:'#00000055',alignItems:'center',justifyContent:'center'},knob:{width:54,height:54,borderRadius:27,backgroundColor:'#ffffff88'},actions:{position:'absolute',right:18,bottom:24,width:250,flexDirection:'row',flexWrap:'wrap',justifyContent:'flex-end',gap:8},button:{minWidth:54,height:48,borderRadius:24,backgroundColor:'#111318cc',borderWidth:1,borderColor:theme.red,alignItems:'center',justifyContent:'center',paddingHorizontal:9},text:{color:'#fff',fontSize:10,fontWeight:'900'}});
