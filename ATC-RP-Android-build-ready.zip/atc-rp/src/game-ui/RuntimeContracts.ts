export type ControlDevice='touch'|'bluetooth-controller'|'keyboard'|'mouse';
export type RoleplayUiEvent =
 | {type:'chat';message:string}
 | {type:'playerList';players:{id:number;name:string;ping:number}[]}
 | {type:'dialog';id:number;title:string;body:string;buttons:string[]}
 | {type:'textDraw';id:number;payload:unknown}
 | {type:'notification';level:'info'|'warning'|'error';message:string}
 | {type:'inventory';payload:unknown}
 | {type:'voiceState';connected:boolean;channel?:string};
export interface VoiceChatAdapter {connect(token:string):Promise<void>; disconnect():Promise<void>; setMuted(muted:boolean):Promise<void>}
