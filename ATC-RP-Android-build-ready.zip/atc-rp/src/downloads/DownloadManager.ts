import {downloads} from '../services/native';
import type {DownloadProgress,ModFile} from '../types';
export class DownloadManager {
  private listeners=new Set<(p:DownloadProgress)=>void>();
  private subscription:any;
  constructor(){this.subscription=downloads.emitter?.addListener('ATCDownloadProgress',(p:DownloadProgress)=>this.listeners.forEach(l=>l(p)))}
  subscribe(fn:(p:DownloadProgress)=>void){this.listeners.add(fn); return ()=>this.listeners.delete(fn)}
  async ensureSpace(files:ModFile[]){const needed=files.reduce((n,f)=>n+f.size,0); const free=await downloads.freeSpace(); if(free<needed*1.15) throw new Error(`Not enough free space. Need about ${Math.ceil(needed*1.15/1024/1024)} MB.`)}
  async downloadFile(modId:string,file:ModFile,index:number){const id=`${modId}:${index}`; return downloads.start(id,file.url,`staging/${modId}/${file.path}`,file.sha256,file.size)}
  cancel(id:string){return downloads.cancel(id)}
  dispose(){this.subscription?.remove?.(); this.listeners.clear()}
}
