import {api} from '../api/client';
import type {Server,NewsItem,Mod,Modpack} from '../types';
export const getServers=()=>api<Server[]>('/servers');
export const getServer=(id:string)=>api<Server>(`/servers/${id}`);
export const getNews=()=>api<NewsItem[]>('/news');
export const getMods=()=>api<Mod[]>('/mods');
export const getModpacks=()=>api<Modpack[]>('/modpacks');
