import {api,setApiToken} from '../api/client';
import {secureStore} from './native';
export type Session={token:string; user:{id:string;username:string;avatar?:string;stats?:Record<string,number>}};
const KEY='atc.session';
export async function restoreSession():Promise<Session|null>{
  try { const raw=await secureStore.get(KEY); if(!raw) return null; const s=JSON.parse(raw); setApiToken(s.token); return s; } catch { return null; }
}
export async function login(username:string,password:string,remember=true):Promise<Session>{
  const s=await api<Session>('/auth/login',{method:'POST',body:JSON.stringify({username,password})}); setApiToken(s.token); if(remember) await secureStore.set(KEY,JSON.stringify(s)); return s;
}
export async function register(username:string,password:string):Promise<Session>{
  const s=await api<Session>('/auth/register',{method:'POST',body:JSON.stringify({username,password})}); setApiToken(s.token); await secureStore.set(KEY,JSON.stringify(s)); return s;
}
export async function logout(){setApiToken(null); await secureStore.remove(KEY)}
