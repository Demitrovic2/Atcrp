import {NativeEventEmitter, NativeModules, Platform} from 'react-native';
const {ATCGameRuntime, ATCDownload, ATCSecureStore} = NativeModules;
export const runtime = {
  capabilities:()=>ATCGameRuntime.getCapabilities(),
  validate:()=>ATCGameRuntime.validateRuntime(),
  prepare:()=>ATCGameRuntime.prepareRuntime(),
  installAsset:(staged:string,target:string,sha256:string,backup=true)=>ATCGameRuntime.installAsset(staged,target,sha256,backup),
  removeAsset:(target:string)=>ATCGameRuntime.removeAsset(target),
  launch:(host:string,port:number,nickname:string,authToken:string)=>ATCGameRuntime.launch(host,port,nickname,authToken),
};
export const downloads = {
  start:(id:string,url:string,destination:string,sha256:string,size:number)=>ATCDownload.start(id,url,destination,sha256,size),
  cancel:(id:string)=>ATCDownload.cancel(id),
  freeSpace:()=>ATCDownload.getFreeSpace(),
  emitter: ATCDownload ? new NativeEventEmitter(ATCDownload) : null,
};
export const secureStore = {
  set:(k:string,v:string)=>ATCSecureStore.set(k,v), get:(k:string)=>ATCSecureStore.get(k), remove:(k:string)=>ATCSecureStore.remove(k)
};
export const platform=Platform.OS;
