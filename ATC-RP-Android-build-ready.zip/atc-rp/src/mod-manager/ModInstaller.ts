import type {Mod} from '../types';
import {DownloadManager} from '../downloads/DownloadManager';
import {runtime} from '../services/native';
import {localModDb} from '../store/localDb';
export class ModInstaller {
  dm=new DownloadManager();
  async install(mod:Mod){
    const validation=await runtime.validate(); if(!validation.ok) throw new Error(validation.message||'Game runtime is not ready');
    await this.dm.ensureSpace(mod.files);
    for(let i=0;i<mod.files.length;i++){const f=mod.files[i];await this.dm.downloadFile(mod.id,f,i);await runtime.installAsset(`staging/${mod.id}/${f.path}`,f.installPath,f.sha256,true)}
    await localModDb.put({id:mod.id,version:mod.version,enabled:true,installedAt:new Date().toISOString(),files:mod.files.map(f=>({path:f.installPath,sha256:f.sha256}))});
    return {ok:true};
  }
  async remove(modId:string){const m=await localModDb.get(modId);if(!m)return;for(const f of m.files)await runtime.removeAsset(f.path);await localModDb.remove(modId)}
  async setEnabled(modId:string,enabled:boolean){await localModDb.setEnabled(modId,enabled)}
  installed(){return localModDb.list()}
}
