import React from 'react';
import {Pressable,StyleSheet,Text,View,ViewStyle} from 'react-native';
import {theme} from '../theme';
export const Card=({children,style}:{children:React.ReactNode;style?:ViewStyle})=><View style={[s.card,style]}>{children}</View>;
export const Title=({children}:{children:React.ReactNode})=><Text style={s.title}>{children}</Text>;
export const Muted=({children}:{children:React.ReactNode})=><Text style={s.muted}>{children}</Text>;
export const Button=({label,onPress,disabled=false,small=false}:{label:string;onPress:()=>void;disabled?:boolean;small?:boolean})=><Pressable disabled={disabled} onPress={onPress} style={({pressed})=>[s.btn,small&&s.small,disabled&&s.disabled,pressed&&{opacity:.8}]}><Text style={s.btnText}>{label}</Text></Pressable>;
const s=StyleSheet.create({card:{backgroundColor:theme.panel,borderWidth:1,borderColor:theme.border,borderRadius:18,padding:16,gap:8},title:{color:theme.text,fontSize:22,fontWeight:'800'},muted:{color:theme.muted,fontSize:13},btn:{backgroundColor:theme.red,borderRadius:14,paddingVertical:15,paddingHorizontal:18,alignItems:'center'},small:{paddingVertical:9,paddingHorizontal:12,borderRadius:10},disabled:{opacity:.4},btnText:{color:'#fff',fontWeight:'900',letterSpacing:.4}})
