import React from 'react'; import {Pressable,StyleSheet,Text,View} from 'react-native'; import {theme} from '../theme';
export type Tab='Home'|'Servers'|'Mods'|'Profile'|'Settings';
export function BottomNav({tab,setTab}:{tab:Tab;setTab:(t:Tab)=>void}){return <View style={s.bar}>{(['Home','Servers','Mods','Profile','Settings'] as Tab[]).map(t=><Pressable key={t} onPress={()=>setTab(t)} style={s.item}><Text style={[s.txt,tab===t&&s.active]}>{t}</Text></Pressable>)}</View>}
const s=StyleSheet.create({bar:{height:68,flexDirection:'row',backgroundColor:'#0d0f13',borderTopWidth:1,borderColor:theme.border},item:{flex:1,alignItems:'center',justifyContent:'center'},txt:{color:theme.muted,fontSize:12,fontWeight:'700'},active:{color:theme.red2}})
