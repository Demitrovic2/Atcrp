import dgram from 'node:dgram';
import {promises as dns} from 'node:dns';
export type SampInfo={online:number;maxPlayers:number;ping:number;hostname:string;gamemode:string;language:string};
const str=(b:Buffer,o:{v:number})=>{if(o.v+4>b.length)throw new Error('short');const n=b.readUInt32LE(o.v);o.v+=4;if(n>4096||o.v+n>b.length)throw new Error('bad length');const s=b.subarray(o.v,o.v+n).toString('latin1');o.v+=n;return s};
export async function querySamp(host:string,port:number,timeout=650):Promise<SampInfo>{
 const ip=(await dns.resolve4(host))[0]||host;const oct=ip.split('.').map(Number);if(oct.length!==4||oct.some(x=>!Number.isInteger(x)||x<0||x>255))throw new Error('IPv4 required');
 const packet=Buffer.alloc(11);packet.write('SAMP',0,'ascii');oct.forEach((x,i)=>packet[4+i]=x);packet.writeUInt16LE(port,8);packet[10]='i'.charCodeAt(0);const started=Date.now();
 return await new Promise<SampInfo>((resolve,reject)=>{const socket=dgram.createSocket('udp4');const timer=setTimeout(()=>{socket.close();reject(new Error('timeout'))},timeout);socket.once('error',e=>{clearTimeout(timer);socket.close();reject(e)});socket.once('message',msg=>{clearTimeout(timer);socket.close();try{if(msg.length<16||msg.subarray(0,4).toString()!=='SAMP')throw new Error('invalid response');const o={v:11};o.v+=1;const online=msg.readUInt16LE(o.v);o.v+=2;const maxPlayers=msg.readUInt16LE(o.v);o.v+=2;const hostname=str(msg,o);const gamemode=str(msg,o);const language=str(msg,o);resolve({online,maxPlayers,ping:Date.now()-started,hostname,gamemode,language})}catch(e){reject(e)}});socket.send(packet,port,ip)});
}
