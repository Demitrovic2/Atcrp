import fs from 'node:fs'; import {db} from './db.js';
const schema=fs.readFileSync(new URL('../database/schema.sql',import.meta.url),'utf8'); db.exec(schema);
const putServer=db.prepare(`INSERT OR REPLACE INTO servers(id,name,host,port,ping,online,max_players,status,featured,version,description,rules_json,discord_url) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`);
putServer.run('atc-rp','ATC RP Roleplay','play.atcrp.example',7777,null,0,300,'maintenance',1,'mobile-runtime-licensed-v1','Official ATC RP server',JSON.stringify(['Roleplay at all times','No cheating','Respect players and staff']),'https://discord.gg/example');
db.prepare(`INSERT OR REPLACE INTO news(id,title,body,published_at) VALUES(?,?,?,?)`).run('welcome','ATC RP launcher foundation','Launcher APIs and mod manifests are online. Game runtime integration remains a licensed native component.','2026-09-20T00:00:00Z');

db.prepare(`INSERT OR REPLACE INTO modpacks(id,name,version,description,categories_json,mods_json,enabled) VALUES(?,?,?,?,?,?,1)`).run('ultra-realistic','ATC RP ULTRA REALISTIC','1.0.0','Modular authorized assets for cars, bikes, skins, textures, sounds, UI and effects.',JSON.stringify(['cars','bikes','skins','weapons','textures','maps','sounds','ui','effects']),JSON.stringify([]));
console.log('Database initialized:',process.env.DB_PATH||'./data/atcrp.db');
