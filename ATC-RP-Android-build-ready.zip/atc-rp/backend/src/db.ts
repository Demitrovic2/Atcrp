import Database from 'better-sqlite3'; import fs from 'node:fs'; import path from 'node:path';
const dbPath=process.env.DB_PATH||'./data/atcrp.db'; fs.mkdirSync(path.dirname(dbPath),{recursive:true}); export const db=new Database(dbPath); db.pragma('journal_mode = WAL');
